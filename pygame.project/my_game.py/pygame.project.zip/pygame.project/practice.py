lst = ["가","나","다"]
for lst_idx, lst_val in enumerate(lst):
    print(lst_idx + 1,lst_val  + "ㅋ")