import pygame
import os

pygame.init()

screen_width = 640
screen_height = 480
screen = pygame.display.set_mode((screen_width, screen_height))

pygame.display.set_caption('roois pang')

clock = pygame.time.Clock()

current_path = os.path.dirname(__file__)
image_path = os.path.join(current_path, 'image')

bg = pygame.image.load(os.path.join(image_path, 'bg.png'))

stage = pygame.image.load(os.path.join(image_path, 's.png'))
stage_size = stage.get_rect().size
stage_height = stage_size[1]

c = pygame.image.load(os.path.join(image_path, 'c.png'))
c_size = c.get_rect().size
c_w = c_size[0]
c_h = c_size[1]
c_x_pos = (screen_width / 2) - (c_w / 2)
c_y_pos = screen_height - c_h - stage_height

c_to_x = 0

c_speed = 5

w = pygame.image.load(os.path.join(image_path, 'w.png'))
w_size = w.get_rect().size
w_w = w_size[0]

ws = []

w_s = 10

ball_image = [
        pygame.image.load(os.path.join(image_path, 'b.png')),
        pygame.image.load(os.path.join(image_path, 'b1.png')),
        pygame.image.load(os.path.join(image_path, 'b2.png')),
        pygame.image.load(os.path.join(image_path, 'b3.png'))]

b_s_y = [-18, -15, -12, -9]

bs = []

bs.append({
    'pos_x' : 50,
    'pos_y' : 50,
    'img_idx' : 0,
    'to_x' : 3,
    'to_y' : -6,
    'init_spd_y' : b_s_y[0]})

w_to_remove = -1
b_to_remove = -1

g_f = pygame.font.Font(None, 40)
tatal_time = 15
start_ticks = pygame.time.get_ticks()

g_result = 'Game Over'

running = True
while running:
    dt = clock.tick(30)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                c_to_x -= c_speed
            elif event.key == pygame.K_RIGHT:
                c_to_x += c_speed
            elif event.key == pygame.K_SPACE:
                w_x_pos = c_x_pos + (c_w / 2) - (w_w /2)
                w_y_pos = c_y_pos
                ws.append([w_x_pos, w_y_pos])


        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                c_to_x = 0

    c_x_pos += c_to_x

    if c_x_pos < 0:
        c_x_pos = 0
    elif c_x_pos > screen_width - c_w:
        c_x_pos = screen_width - c_w

    
    ws = [ [w[0], w[1] - w_s] for w in ws]

    ws = [ [w[0], w[1]] for w in ws if w[1] > 0]

    for ball_indx, ball_val in enumerate(bs):
        ball_pos_x = ball_val['pos_x']
        ball_pos_y = ball_val['pos_y']
        ball_img_idx = ball_val['img_idx']

        b_s = ball_image[ball_img_idx].get_rect().size
        b_w = b_s[0]
        b_h = b_s[1]

        if ball_pos_x < 0 or ball_pos_x > screen_width - b_w:
            ball_val['to_x'] = ball_val['to_x']  * -1

        if ball_pos_y >= screen_height - stage_height - b_h:
            ball_val['to_y'] = ball_val['init_spd_y']
        else:
            ball_val['to_y'] += 0.5
        
        ball_val['pos_x'] += ball_val['to_x']
        ball_val['pos_y'] += ball_val['to_y']

    c_rect = c.get_rect()
    c_rect.left = c_x_pos
    c_rect.top = c_y_pos

    for ball_indx, ball_val in enumerate(bs):
        ball_pos_x = ball_val['pos_x']
        ball_pos_y = ball_val['pos_y']
        ball_img_idx = ball_val['img_idx']

        b_rect = ball_image[ball_img_idx].get_rect()
        b_rect.left = ball_pos_x
        b_rect.top = ball_pos_y

        if c_rect.colliderect(b_rect):
            running = False
            break

        for w_indx, w_val in enumerate(ws):
            w_pos_x = w_val[0]
            w_pos_y = w_val[1]

            w_rect = w.get_rect()
            w_rect.left = w_pos_x
            w_rect.top = w_pos_y

            if w_rect.colliderect(b_rect):
                w_to_remove = w_indx
                b_to_remove = ball_indx

                if ball_img_idx < 3:
                    b_w = b_rect.size[0]
                    b_h = b_rect.size[1]

                    small_ball_rect = ball_image[ball_img_idx + 1].get_rect()
                    small_ball_w = small_ball_rect.size[0]
                    small_ball_h = small_ball_rect.size[1]

                    bs.append({
                        'pos_x' : ball_pos_x + (b_w / 2) - (small_ball_w / 2),
                        'pos_y' : ball_pos_y + (b_h /2) - (small_ball_h / 2),
                        'img_idx' : ball_img_idx + 1,
                        'to_x' : -3,
                        'to_y' : -6,
                        'init_spd_y' : b_s_y[ball_img_idx + 1]})
                    
                    bs.append({
                        'pos_x' : ball_pos_x + (b_w / 2) - (small_ball_w / 2),
                        'pos_y' : ball_pos_y + (b_h /2) - (small_ball_h / 2),
                        'img_idx' : ball_img_idx + 1,
                        'to_x' : 3,
                        'to_y' : -6,
                        'init_spd_y' : b_s_y[ball_img_idx + 1]})

                break
        else:
            continue
        break

    if b_to_remove > -1:
        del bs[b_to_remove]
        b_to_remove = -1

    if w_to_remove > -1:
        del ws[w_to_remove]
        w_to_remove = -1

    if len(bs) == 0:
        g_result = 'Mission Complete'
        running = False
    screen.blit(bg, (0, 0))

    for w_x_pos, w_y_pos in ws:
        screen.blit(w, (w_x_pos, w_y_pos))
    
    for idx, val in enumerate(bs):
        ball_pos_x = val['pos_x']
        ball_pos_y = val['pos_y']
        ball_img_idx = val['img_idx']
        screen.blit(ball_image[ball_img_idx], (ball_pos_x, ball_pos_y))

    screen.blit(stage, (0, screen_height - stage_height))
    screen.blit(c, (c_x_pos, c_y_pos))

    e_t = (pygame.time.get_ticks() - start_ticks) / 1000
    timer = g_f.render('Time : {}'.format(int(tatal_time - e_t)), True, (255, 255, 255))
    screen.blit(timer,(10, 10))

    if tatal_time - e_t <= 0:
        g_result = 'Time Over'
        running = False
    
    pygame.display.update()

msg = g_f.render(g_result, True, (255, 255, 0))
msg_rect = msg.get_rect(center=(int(screen_width / 2), int(screen_height / 2)))
screen.blit(msg, msg_rect)
pygame.display.update()

pygame.time.delay(2000)

pygame.quit()